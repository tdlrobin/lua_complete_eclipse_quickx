-- @module CCEaseBackIn

-----------------------
-- @function [parent=#CCEaseBackIn] create
-- @param  pAction

-----------------------
return nil
