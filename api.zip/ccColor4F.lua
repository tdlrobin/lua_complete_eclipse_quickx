-- @module ccColor4F

-----------------------
-- @function [parent=#ccColor4F] ccColor4F
-- @param  self

-----------------------
-- @function [parent=#ccColor4F] ccColor4F
-- @param  self

-----------------------
return nil
