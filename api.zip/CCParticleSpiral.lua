-- @module CCParticleSpiral

-----------------------
-- @function [parent=#CCParticleSpiral] createWithTotalParticles
-- @param  numberOfParticles

-----------------------
-- @function [parent=#CCParticleSpiral] create

-----------------------
return nil
