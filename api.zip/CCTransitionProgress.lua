-- @module CCTransitionProgress

-----------------------
return nil
