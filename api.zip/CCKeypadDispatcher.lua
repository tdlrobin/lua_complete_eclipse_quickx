-- @module CCKeypadDispatcher

-----------------------
-- @function [parent=#CCKeypadDispatcher] dispatchKeypadMSG
-- @param  self
-- @param  nMsgType

-----------------------
return nil
