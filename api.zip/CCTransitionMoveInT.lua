-- @module CCTransitionMoveInT

-----------------------
-- @function [parent=#CCTransitionMoveInT] create
-- @param  t
-- @param  scene

-----------------------
return nil
