-- @module CCTexture2D

-----------------------
-- @function [parent=#CCTexture2D] setTexParameters
-- @param  self
-- @param  texParams

-----------------------
-- @function [parent=#CCTexture2D] setAntiAliasTexParameters
-- @param  self

-----------------------
-- @function [parent=#CCTexture2D] setAliasTexParameters
-- @param  self

-----------------------
-- @function [parent=#CCTexture2D] generateMipmap
-- @param  self

-----------------------
-- @function [parent=#CCTexture2D] stringForFormat
-- @param  self

-----------------------
-- @function [parent=#CCTexture2D] bitsPerPixelForFormat
-- @param  self

-----------------------
-- @function [parent=#CCTexture2D] bitsPerPixelForFormat
-- @param  self
-- @param  format

-----------------------
-- @function [parent=#CCTexture2D] setDefaultAlphaPixelFormat
-- @param  format

-----------------------
-- @function [parent=#CCTexture2D] defaultAlphaPixelFormat

-----------------------
-- @function [parent=#CCTexture2D] PVRImagesHavePremultipliedAlpha
-- @param  haveAlphaPremultiplied

-----------------------
-- @function [parent=#CCTexture2D] getContentSizeInPixels
-- @param  self

-----------------------
-- @function [parent=#CCTexture2D] getPixelFormat
-- @param  self

-----------------------
-- @function [parent=#CCTexture2D] getPixelsWide
-- @param  self

-----------------------
-- @function [parent=#CCTexture2D] getPixelsHigh
-- @param  self

-----------------------
-- @function [parent=#CCTexture2D] getName
-- @param  self

-----------------------
-- @function [parent=#CCTexture2D] getMaxS
-- @param  self

-----------------------
-- @function [parent=#CCTexture2D] getMaxT
-- @param  self

-----------------------
-- @function [parent=#CCTexture2D] getContentSize
-- @param  self

-----------------------
-- @function [parent=#CCTexture2D] getShaderProgram
-- @param  self

-----------------------
-- @function [parent=#CCTexture2D] hasPremultipliedAlpha
-- @param  self

-----------------------
-- @function [parent=#CCTexture2D] hasMipmaps
-- @param  self

-----------------------
return nil
