-- @module CCEaseSineIn

-----------------------
-- @function [parent=#CCEaseSineIn] create
-- @param  pAction

-----------------------
return nil
