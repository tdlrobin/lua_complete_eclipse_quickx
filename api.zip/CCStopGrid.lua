-- @module CCStopGrid

-----------------------
-- @function [parent=#CCStopGrid] create
-- @param  void

-----------------------
return nil
