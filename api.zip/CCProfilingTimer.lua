-- @module CCProfilingTimer

-----------------------
-- @function [parent=#CCProfilingTimer] getStartTime
-- @param  self
-- @param  void

-----------------------
-- @function [parent=#CCProfilingTimer] setAverageTime
-- @param  self
-- @param  value

-----------------------
-- @function [parent=#CCProfilingTimer] getAverageTime
-- @param  self
-- @param  void

-----------------------
-- @function [parent=#CCProfilingTimer] reset
-- @param  self

-----------------------
return nil
