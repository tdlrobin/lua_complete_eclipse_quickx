-- @module CCControlSwitch

-----------------------
-- @function [parent=#CCControlSwitch] create
-- @param  maskSprite
-- @param  onSprite
-- @param  offSprite
-- @param  thumbSprite
-- @param  onLabel
-- @param  offLabel

-----------------------
-- @function [parent=#CCControlSwitch] create
-- @param  maskSprite
-- @param  onSprite
-- @param  offSprite
-- @param  thumbSprite

-----------------------
-- @function [parent=#CCControlSwitch] setOn
-- @param  self
-- @param  isOn
-- @param  animated

-----------------------
-- @function [parent=#CCControlSwitch] setOn
-- @param  self
-- @param  isOn

-----------------------
-- @function [parent=#CCControlSwitch] isOn
-- @param  self
-- @param  void

-----------------------
-- @function [parent=#CCControlSwitch] hasMoved
-- @param  self

-----------------------
return nil
