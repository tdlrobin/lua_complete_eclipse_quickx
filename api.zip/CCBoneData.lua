-- @module CCBoneData

-----------------------
-- @function [parent=#CCBoneData] create

-----------------------
-- @function [parent=#CCBoneData] addDisplayData
-- @param  self
-- @param  displayData

-----------------------
-- @function [parent=#CCBoneData] getDisplayData
-- @param  self
-- @param  index

-----------------------
return nil
