-- @module CCEaseElastic

-----------------------
-- @function [parent=#CCEaseElastic] create
-- @param  pAction
-- @param  fPeriod

-----------------------
-- @function [parent=#CCEaseElastic] create
-- @param  pAction

-----------------------
return nil
