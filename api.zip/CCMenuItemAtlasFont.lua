-- @module CCMenuItemAtlasFont

-----------------------
-- @function [parent=#CCMenuItemAtlasFont] create
-- @param  value
-- @param  charMapFile
-- @param  itemWidth
-- @param  itemHeight
-- @param  startCharMap

-----------------------
return nil
