-- @module CCSpriteFrameCache

-----------------------
-- @function [parent=#CCSpriteFrameCache] addSpriteFramesWithFile
-- @param  self
-- @param  plist
-- @param  textureFileName

-----------------------
-- @function [parent=#CCSpriteFrameCache] addSpriteFramesWithFile
-- @param  self
-- @param  pszPlist
-- @param  pobTexture

-----------------------
-- @function [parent=#CCSpriteFrameCache] addSpriteFramesWithFile
-- @param  self
-- @param  pszPlist

-----------------------
-- @function [parent=#CCSpriteFrameCache] addSpriteFrame
-- @param  self
-- @param  pobFrame
-- @param  pszFrameName

-----------------------
-- @function [parent=#CCSpriteFrameCache] removeSpriteFrames
-- @param  self
-- @param  void

-----------------------
-- @function [parent=#CCSpriteFrameCache] removeUnusedSpriteFrames
-- @param  self
-- @param  void

-----------------------
-- @function [parent=#CCSpriteFrameCache] removeSpriteFrameByName
-- @param  self
-- @param  pszName

-----------------------
-- @function [parent=#CCSpriteFrameCache] removeSpriteFramesFromFile
-- @param  self
-- @param  plist

-----------------------
-- @function [parent=#CCSpriteFrameCache] removeSpriteFramesFromTexture
-- @param  self
-- @param  texture

-----------------------
-- @function [parent=#CCSpriteFrameCache] spriteFrameByName
-- @param  self
-- @param  pszName

-----------------------
-- @function [parent=#CCSpriteFrameCache] sharedSpriteFrameCache
-- @param  void

-----------------------
-- @function [parent=#CCSpriteFrameCache] purgeSharedSpriteFrameCache
-- @param  void

-----------------------
return nil
