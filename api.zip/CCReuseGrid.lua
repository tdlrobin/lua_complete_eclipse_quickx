-- @module CCReuseGrid

-----------------------
-- @function [parent=#CCReuseGrid] create
-- @param  times

-----------------------
return nil
