-- @module CCFadeOutDownTiles

-----------------------
-- @function [parent=#CCFadeOutDownTiles] create
-- @param  duration
-- @param  gridSize

-----------------------
return nil
