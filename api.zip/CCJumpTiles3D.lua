-- @module CCJumpTiles3D

-----------------------
-- @function [parent=#CCJumpTiles3D] create
-- @param  duration
-- @param  gridSize
-- @param  numberOfJumps
-- @param  amplitude

-----------------------
return nil
