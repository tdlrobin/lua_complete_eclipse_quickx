-- @module CCLayerGradient

-----------------------
-- @function [parent=#CCLayerGradient] create
-- @param  start
-- @param  end
-- @param  v

-----------------------
-- @function [parent=#CCLayerGradient] create
-- @param  start
-- @param  end

-----------------------
-- @function [parent=#CCLayerGradient] create

-----------------------
-- @function [parent=#CCLayerGradient] getStartColor
-- @param  self

-----------------------
-- @function [parent=#CCLayerGradient] setStartColor
-- @param  self
-- @param  color

-----------------------
-- @function [parent=#CCLayerGradient] getEndColor
-- @param  self

-----------------------
-- @function [parent=#CCLayerGradient] setEndColor
-- @param  self
-- @param  color

-----------------------
-- @function [parent=#CCLayerGradient] getStartOpacity
-- @param  self

-----------------------
-- @function [parent=#CCLayerGradient] setStartOpacity
-- @param  self
-- @param  opacity

-----------------------
-- @function [parent=#CCLayerGradient] getEndOpacity
-- @param  self

-----------------------
-- @function [parent=#CCLayerGradient] setEndOpacity
-- @param  self
-- @param  opacity

-----------------------
-- @function [parent=#CCLayerGradient] getVector
-- @param  self

-----------------------
-- @function [parent=#CCLayerGradient] setVector
-- @param  self
-- @param  vector

-----------------------
-- @function [parent=#CCLayerGradient] setCompressedInterpolation
-- @param  self
-- @param  bCompressedInterpolation

-----------------------
-- @function [parent=#CCLayerGradient] isCompressedInterpolation
-- @param  self

-----------------------
return nil
