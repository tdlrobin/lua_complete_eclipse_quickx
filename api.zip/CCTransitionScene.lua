-- @module CCTransitionScene

-----------------------
return nil
