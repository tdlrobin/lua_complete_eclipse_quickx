-- @module CCApplication

-----------------------
-- @function [parent=#CCApplication] sharedApplication

-----------------------
-- @function [parent=#CCApplication] setAnimationInterval
-- @param  self
-- @param  interval

-----------------------
-- @function [parent=#CCApplication] getCurrentLanguage
-- @param  self

-----------------------
-- @function [parent=#CCApplication] getTargetPlatform
-- @param  self

-----------------------
return nil
