-- @module CCBool

-----------------------
-- @function [parent=#CCBool] CCBool
-- @param  self
-- @param  v

-----------------------
-- @function [parent=#CCBool] getValue
-- @param  self

-----------------------
-- @function [parent=#CCBool] create
-- @param  v

-----------------------
return nil
