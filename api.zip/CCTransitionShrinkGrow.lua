-- @module CCTransitionShrinkGrow

-----------------------
-- @function [parent=#CCTransitionShrinkGrow] create
-- @param  t
-- @param  scene

-----------------------
return nil
