-- @module CCEGLView

-----------------------
-- @function [parent=#CCEGLView] sharedOpenGLView
-- @param  void

-----------------------
-- @function [parent=#CCEGLView] getFrameSize
-- @param  self

-----------------------
-- @function [parent=#CCEGLView] setFrameSize
-- @param  self
-- @param  width
-- @param  height

-----------------------
-- @function [parent=#CCEGLView] getVisibleSize
-- @param  self

-----------------------
-- @function [parent=#CCEGLView] getVisibleOrigin
-- @param  self

-----------------------
-- @function [parent=#CCEGLView] setDesignResolutionSize
-- @param  self
-- @param  width
-- @param  height
-- @param  resolutionPolicy

-----------------------
-- @function [parent=#CCEGLView] getDesignResolutionSize
-- @param  self

-----------------------
-- @function [parent=#CCEGLView] setViewPortInPoints
-- @param  self
-- @param  x
-- @param  y
-- @param  w
-- @param  h

-----------------------
-- @function [parent=#CCEGLView] setScissorInPoints
-- @param  self
-- @param  x
-- @param  y
-- @param  w
-- @param  h

-----------------------
-- @function [parent=#CCEGLView] isScissorEnabled
-- @param  self

-----------------------
-- @function [parent=#CCEGLView] getScissorRect
-- @param  self

-----------------------
-- @function [parent=#CCEGLView] getViewPortRect
-- @param  self

-----------------------
-- @function [parent=#CCEGLView] getScaleX
-- @param  self

-----------------------
-- @function [parent=#CCEGLView] getScaleY
-- @param  self

-----------------------
return nil
