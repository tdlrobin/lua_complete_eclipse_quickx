-- @module CCArmatureData

-----------------------
-- @function [parent=#CCArmatureData] create

-----------------------
-- @function [parent=#CCArmatureData] addBoneData
-- @param  self
-- @param  boneData

-----------------------
-- @function [parent=#CCArmatureData] getBoneData
-- @param  self
-- @param  boneName

-----------------------
return nil
