-- @module Timer

-----------------------
-- @function [parent=#Timer] new

-----------------------
return nil
