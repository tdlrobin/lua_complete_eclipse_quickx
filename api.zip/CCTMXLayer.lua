-- @module CCTMXLayer

-----------------------
-- @function [parent=#CCTMXLayer] CCTMXLayer
-- @param  self

-----------------------
-- @function [parent=#CCTMXLayer] CCTMXLayer
-- @param  self

-----------------------
-- @function [parent=#CCTMXLayer] create
-- @param  tilesetInfo
-- @param  layerInfo
-- @param  mapInfo

-----------------------
-- @function [parent=#CCTMXLayer] initWithTilesetInfo
-- @param  self
-- @param  tilesetInfo
-- @param  layerInfo
-- @param  mapInfo

-----------------------
-- @function [parent=#CCTMXLayer] getLayerSize
-- @param  self

-----------------------
-- @function [parent=#CCTMXLayer] getMapTileSize
-- @param  self

-----------------------
-- @function [parent=#CCTMXLayer] getTileSet
-- @param  self

-----------------------
-- @function [parent=#CCTMXLayer] getLayerOrientation
-- @param  self

-----------------------
-- @function [parent=#CCTMXLayer] getProperties
-- @param  self

-----------------------
-- @function [parent=#CCTMXLayer] releaseMap
-- @param  self

-----------------------
-- @function [parent=#CCTMXLayer] removeChild
-- @param  self
-- @param  sprite
-- @param  cleanup

-----------------------
-- @function [parent=#CCTMXLayer] removeTileAt
-- @param  self
-- @param  x
-- @param  - or layer->

-----------------------
-- @function [parent=#CCTMXLayer] tileAt
-- @param  self
-- @param  tileCoordinate

-----------------------
-- @function [parent=#CCTMXLayer] tileGIDAt
-- @param  self
-- @param  tileCoordinate

-----------------------
-- @function [parent=#CCTMXLayer] setTileGID
-- @param  self
-- @param  gid
-- @param  tileCoordinate

-----------------------
-- @function [parent=#CCTMXLayer] removeTileAt
-- @param  self
-- @param  tileCoordinate

-----------------------
-- @function [parent=#CCTMXLayer] positionAt
-- @param  self
-- @param  tileCoordinate

-----------------------
-- @function [parent=#CCTMXLayer] propertyNamed
-- @param  self
-- @param  propertyName

-----------------------
-- @function [parent=#CCTMXLayer] getLayerName
-- @param  self

-----------------------
return nil
