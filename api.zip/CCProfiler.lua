-- @module CCProfiler

-----------------------
-- @function [parent=#CCProfiler] sharedProfiler
-- @param  void

-----------------------
-- @function [parent=#CCProfiler] createAndAddTimerWithName
-- @param  self
-- @param  timerName

-----------------------
-- @function [parent=#CCProfiler] releaseTimer
-- @param  self
-- @param  timerName

-----------------------
-- @function [parent=#CCProfiler] releaseAllTimers
-- @param  self

-----------------------
-- @function [parent=#CCProfiler] displayTimers
-- @param  self
-- @param  void

-----------------------
return nil
