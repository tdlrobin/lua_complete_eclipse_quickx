-- @module CCParticleSun

-----------------------
-- @function [parent=#CCParticleSun] createWithTotalParticles
-- @param  numberOfParticles

-----------------------
-- @function [parent=#CCParticleSun] create

-----------------------
return nil
