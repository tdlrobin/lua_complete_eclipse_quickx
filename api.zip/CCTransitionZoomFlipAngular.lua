-- @module CCTransitionZoomFlipAngular

-----------------------
-- @function [parent=#CCTransitionZoomFlipAngular] create
-- @param  t
-- @param  s
-- @param  o

-----------------------
-- @function [parent=#CCTransitionZoomFlipAngular] create
-- @param  t
-- @param  s

-----------------------
return nil
