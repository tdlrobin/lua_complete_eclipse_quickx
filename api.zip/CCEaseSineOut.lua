-- @module CCEaseSineOut

-----------------------
-- @function [parent=#CCEaseSineOut] create
-- @param  pAction

-----------------------
return nil
