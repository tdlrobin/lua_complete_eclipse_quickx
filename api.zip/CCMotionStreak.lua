-- @module CCMotionStreak

-----------------------
-- @function [parent=#CCMotionStreak] create
-- @param  fade
-- @param  minSeg
-- @param  stroke
-- @param  color
-- @param  path

-----------------------
-- @function [parent=#CCMotionStreak] create
-- @param  fade
-- @param  minSeg
-- @param  stroke
-- @param  color
-- @param  texture

-----------------------
-- @function [parent=#CCMotionStreak] tintWithColor
-- @param  self
-- @param  colors

-----------------------
-- @function [parent=#CCMotionStreak] reset
-- @param  self

-----------------------
-- @function [parent=#CCMotionStreak] isFastMode
-- @param  self

-----------------------
-- @function [parent=#CCMotionStreak] setFastMode
-- @param  self
-- @param  bFastMode

-----------------------
-- @function [parent=#CCMotionStreak] isStartingPositionInitialized
-- @param  self

-----------------------
-- @function [parent=#CCMotionStreak] setStartingPositionInitialized
-- @param  self
-- @param  bStartingPositionInitialized

-----------------------
return nil
