-- @module ccBezierConfig

-----------------------
-- @function [parent=#ccBezierConfig] ccBezierConfig
-- @param  self

-----------------------
-- @function [parent=#ccBezierConfig] ccBezierConfig
-- @param  self

-----------------------
return nil
