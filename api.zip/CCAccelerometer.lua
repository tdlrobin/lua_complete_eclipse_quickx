-- @module CCAccelerometer

-----------------------
-- @function [parent=#CCAccelerometer] setAccelerometerInterval
-- @param  self
-- @param  interval

-----------------------
return nil
