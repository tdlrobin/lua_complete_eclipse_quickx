-- @module CCBone

-----------------------
-- @function [parent=#CCBone] create
-- @param  name

-----------------------
-- @function [parent=#CCBone] create

-----------------------
-- @function [parent=#CCBone] addChildBone
-- @param  self
-- @param  _child

-----------------------
-- @function [parent=#CCBone] getParentBone
-- @param  self

-----------------------
-- @function [parent=#CCBone] removeFromParent
-- @param  self
-- @param  true

-----------------------
-- @function [parent=#CCBone] removeChildBone
-- @param  self
-- @param  bone
-- @param  true

-----------------------
-- @function [parent=#CCBone] setIgnoreMovementBoneData
-- @param  self
-- @param  bool

-----------------------
-- @function [parent=#CCBone] getIgnoreMovementBoneData
-- @param  self

-----------------------
-- @function [parent=#CCBone] getName
-- @param  self

-----------------------
return nil
