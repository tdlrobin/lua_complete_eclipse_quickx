-- @module Context

-----------------------
-- @function [parent=#Context] ctor
-- @param  self

-----------------------
-- @function [parent=#Context] get
-- @param  self
-- @param  key
-- @param  defaultValue

-----------------------
-- @function [parent=#Context] set
-- @param  self
-- @param  key
-- @param  value

-----------------------
return nil
