-- @module CCEaseExponentialIn

-----------------------
-- @function [parent=#CCEaseExponentialIn] create
-- @param  pAction

-----------------------
return nil
