-- @module CCTwirl

-----------------------
-- @function [parent=#CCTwirl] create
-- @param  duration
-- @param  gridSize
-- @param  position
-- @param  twirls
-- @param  amplitude

-----------------------
return nil
