-- @module CCActionInterval

-----------------------
-- @function [parent=#CCActionInterval] copy
-- @param  self
-- @param  void

-----------------------
return nil
