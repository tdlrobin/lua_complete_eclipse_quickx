-- @module CCTime

-----------------------
-- @function [parent=#CCTime] gettimeofdayCocos2d
-- @param  tp
-- @param  tzp

-----------------------
-- @function [parent=#CCTime] timersubCocos2d
-- @param  start
-- @param  end

-----------------------
return nil
