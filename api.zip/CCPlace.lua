-- @module CCPlace

-----------------------
-- @function [parent=#CCPlace] create
-- @param  pos

-----------------------
return nil
