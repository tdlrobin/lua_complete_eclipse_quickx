-- @module CCControl

-----------------------
-- @function [parent=#CCControl] getState
-- @param  self

-----------------------
-- @function [parent=#CCControl] setEnabled
-- @param  self
-- @param  bEnabled

-----------------------
-- @function [parent=#CCControl] isEnabled
-- @param  self

-----------------------
-- @function [parent=#CCControl] setSelected
-- @param  self
-- @param  bSelected

-----------------------
-- @function [parent=#CCControl] isSelected
-- @param  self

-----------------------
-- @function [parent=#CCControl] setHighlighted
-- @param  self
-- @param  bHighlighted

-----------------------
-- @function [parent=#CCControl] isHighlighted
-- @param  self

-----------------------
-- @function [parent=#CCControl] hasVisibleParents
-- @param  self

-----------------------
-- @function [parent=#CCControl] isOpacityModifyRGB
-- @param  self

-----------------------
-- @function [parent=#CCControl] setOpacityModifyRGB
-- @param  self
-- @param  bOpacityModifyRGB

-----------------------
-- @function [parent=#CCControl] sendActionsForControlEvents
-- @param  self
-- @param  controlEvents

-----------------------
-- @function [parent=#CCControl] addHandleOfControlEvent
-- @param  self
-- @param  nFunID
-- @param  controlEvent

-----------------------
-- @function [parent=#CCControl] removeHandleOfControlEvent
-- @param  self
-- @param  controlEvent

-----------------------
return nil
