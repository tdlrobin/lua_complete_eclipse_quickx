-- @module CCComponent

-----------------------
-- @function [parent=#CCComponent] create
-- @param  void

-----------------------
-- @function [parent=#CCComponent] isEnabled
-- @param  self

-----------------------
-- @function [parent=#CCComponent] setEnabled
-- @param  self
-- @param  b

-----------------------
-- @function [parent=#CCComponent] getName
-- @param  self

-----------------------
-- @function [parent=#CCComponent] setOwner
-- @param  self
-- @param  pOwner

-----------------------
-- @function [parent=#CCComponent] getOwner
-- @param  self

-----------------------
return nil
