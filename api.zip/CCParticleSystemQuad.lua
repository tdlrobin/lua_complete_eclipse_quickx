-- @module CCParticleSystemQuad

-----------------------
-- @function [parent=#CCParticleSystemQuad] CCParticleSystemQuad
-- @param  self
-- @param  void

-----------------------
-- @function [parent=#CCParticleSystemQuad] CCParticleSystemQuad
-- @param  self
-- @param  void

-----------------------
-- @function [parent=#CCParticleSystemQuad] initIndices
-- @param  self

-----------------------
-- @function [parent=#CCParticleSystemQuad] initTexCoordsWithRect
-- @param  self
-- @param  rect

-----------------------
-- @function [parent=#CCParticleSystemQuad] setDisplayFrame
-- @param  self
-- @param  spriteFrame

-----------------------
-- @function [parent=#CCParticleSystemQuad] setTextureWithRect
-- @param  self
-- @param  texture
-- @param  rect

-----------------------
-- @function [parent=#CCParticleSystemQuad] initWithTotalParticles
-- @param  self
-- @param  numberOfParticles

-----------------------
-- @function [parent=#CCParticleSystemQuad] setTexture
-- @param  self
-- @param  texture

-----------------------
-- @function [parent=#CCParticleSystemQuad] updateQuadWithParticle
-- @param  self
-- @param  particle
-- @param  newPosition

-----------------------
-- @function [parent=#CCParticleSystemQuad] setBatchNode
-- @param  self
-- @param  batchNode

-----------------------
-- @function [parent=#CCParticleSystemQuad] setTotalParticles
-- @param  self
-- @param  tp

-----------------------
-- @function [parent=#CCParticleSystemQuad] create
-- @param  plistFile

-----------------------
-- @function [parent=#CCParticleSystemQuad] create

-----------------------
-- @function [parent=#CCParticleSystemQuad] createWithTotalParticles
-- @param  numberOfParticles

-----------------------
-- @function [parent=#CCParticleSystemQuad] setDisplayFrame
-- @param  self
-- @param  spriteFrame

-----------------------
-- @function [parent=#CCParticleSystemQuad] setTextureWithRect
-- @param  self
-- @param  texture
-- @param  rect

-----------------------
return nil
