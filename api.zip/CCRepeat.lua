-- @module CCRepeat

-----------------------
-- @function [parent=#CCRepeat] create
-- @param  pAction
-- @param  times

-----------------------
return nil
