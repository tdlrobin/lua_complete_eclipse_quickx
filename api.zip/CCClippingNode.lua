-- @module CCClippingNode

-----------------------
-- @function [parent=#CCClippingNode] create
-- @param  pStencil

-----------------------
-- @function [parent=#CCClippingNode] create

-----------------------
-- @function [parent=#CCClippingNode] getStencil
-- @param  self

-----------------------
-- @function [parent=#CCClippingNode] setStencil
-- @param  self
-- @param  pStencil

-----------------------
-- @function [parent=#CCClippingNode] getAlphaThreshold
-- @param  self

-----------------------
-- @function [parent=#CCClippingNode] setAlphaThreshold
-- @param  self
-- @param  fAlphaThreshold

-----------------------
-- @function [parent=#CCClippingNode] isInverted
-- @param  self

-----------------------
-- @function [parent=#CCClippingNode] setInverted
-- @param  self
-- @param  bInverted

-----------------------
return nil
