-- @module CCFiniteTimeAction

-----------------------
-- @function [parent=#CCFiniteTimeAction] copy
-- @param  self
-- @param  void

-----------------------
-- @function [parent=#CCFiniteTimeAction] getDuration
-- @param  self
-- @param  void

-----------------------
-- @function [parent=#CCFiniteTimeAction] reverse
-- @param  self
-- @param  void

-----------------------
return nil
