-- @module device

-----------------------
-- @field [parent=#device] platform

-----------------------
-- @field [parent=#device] model

-----------------------
-- @field [parent=#device] platform

-----------------------
-- @field [parent=#device] platform

-----------------------
-- @field [parent=#device] platform

-----------------------
-- @field [parent=#device] platform

-----------------------
-- @field [parent=#device] model

-----------------------
-- @field [parent=#device] model

-----------------------
-- @field [parent=#device] language

-----------------------
-- @field [parent=#device] writablePath

-----------------------
-- @field [parent=#device] cachePath

-----------------------
-- @field [parent=#device] directorySeparator

-----------------------
-- @field [parent=#device] pathSeparator

-----------------------
-- @field [parent=#device] platform

-----------------------
-- @field [parent=#device] directorySeparator

-----------------------
-- @field [parent=#device] pathSeparator

-----------------------
-- @field [parent=#device] platform

-----------------------
-- @field [parent=#device] model

-----------------------
-- @field [parent=#device] language

-----------------------
-- @field [parent=#device] writablePath

-----------------------
-- @field [parent=#device] cachePath

-----------------------
-- @field [parent=#device] directorySeparator

-----------------------
-- @field [parent=#device] pathSeparator

-----------------------
-- @function [parent=#device] showActivityIndicator

-----------------------
-- @function [parent=#device] hideActivityIndicator

-----------------------
-- @function [parent=#device] showAlert
-- @param  title
-- @param  message
-- @param  buttonLabels
-- @param  listener

-----------------------
-- @function [parent=#device] cancelAlert

-----------------------
-- @function [parent=#device] getOpenUDID

-----------------------
-- @function [parent=#device] openURL
-- @param  url

-----------------------
-- @function [parent=#device] showInputBox
-- @param  title
-- @param  message
-- @param  defaultValue

-----------------------
return nil
