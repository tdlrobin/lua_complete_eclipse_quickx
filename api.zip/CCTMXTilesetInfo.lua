-- @module CCTMXTilesetInfo

-----------------------
-- @function [parent=#CCTMXTilesetInfo] CCTMXTilesetInfo
-- @param  self

-----------------------
-- @function [parent=#CCTMXTilesetInfo] CCTMXTilesetInfo
-- @param  self

-----------------------
-- @function [parent=#CCTMXTilesetInfo] rectForGID
-- @param  self
-- @param  gid

-----------------------
return nil
