-- @module CCCardinalSplineBy

-----------------------
-- @function [parent=#CCCardinalSplineBy] create
-- @param  duration
-- @param  points
-- @param  tension

-----------------------
return nil
