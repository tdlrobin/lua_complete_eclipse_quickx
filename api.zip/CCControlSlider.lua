-- @module CCControlSlider

-----------------------
-- @function [parent=#CCControlSlider] getValue
-- @param  self

-----------------------
-- @function [parent=#CCControlSlider] setValue
-- @param  self
-- @param  val

-----------------------
-- @function [parent=#CCControlSlider] getMinimumValue
-- @param  self

-----------------------
-- @function [parent=#CCControlSlider] setMinimumValue
-- @param  self
-- @param  val

-----------------------
-- @function [parent=#CCControlSlider] getMaximumValue
-- @param  self

-----------------------
-- @function [parent=#CCControlSlider] setMaximumValue
-- @param  self
-- @param  val

-----------------------
-- @function [parent=#CCControlSlider] getMinimumAllowedValue
-- @param  self

-----------------------
-- @function [parent=#CCControlSlider] setMinimumAllowedValue
-- @param  self
-- @param  v

-----------------------
-- @function [parent=#CCControlSlider] getMaximumAllowedValue
-- @param  self

-----------------------
-- @function [parent=#CCControlSlider] setMaximumAllowedValue
-- @param  self
-- @param  v

-----------------------
-- @function [parent=#CCControlSlider] create
-- @param  backgroundSprite
-- @param  pogressSprite
-- @param  thumbSprite

-----------------------
-- @function [parent=#CCControlSlider] create
-- @param  bgFile
-- @param  progressFile
-- @param  thumbFile

-----------------------
return nil
