-- @module CCSpriteExtend

-----------------------
-- @field [parent=#CCSpriteExtend] __index

-----------------------
-- @function [parent=#CCSpriteExtend] extend
-- @param  target

-----------------------
-- @function [parent=#CCSpriteExtend] playAnimationOnce
-- @param  self
-- @param  animation
-- @param  removeWhenFinished
-- @param  onComplete
-- @param  delay

-----------------------
-- @function [parent=#CCSpriteExtend] playAnimationForever
-- @param  self
-- @param  animation
-- @param  delay

-----------------------
return nil
