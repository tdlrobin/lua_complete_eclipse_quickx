-- @module CCTransitionSlideInB

-----------------------
-- @function [parent=#CCTransitionSlideInB] create
-- @param  t
-- @param  scene

-----------------------
return nil
