-- @module json

-----------------------
-- @function [parent=#json] encode
-- @param  var

-----------------------
-- @function [parent=#json] decode
-- @param  text

-----------------------
return nil
