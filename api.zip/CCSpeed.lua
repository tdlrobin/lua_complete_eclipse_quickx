-- @module CCSpeed

-----------------------
-- @function [parent=#CCSpeed] getSpeed
-- @param  self
-- @param  void

-----------------------
-- @function [parent=#CCSpeed] setSpeed
-- @param  self
-- @param  fSpeed

-----------------------
-- @function [parent=#CCSpeed] create
-- @param  pAction
-- @param  fSpeed

-----------------------
return nil
