-- @module CCDevice

-----------------------
-- @function [parent=#CCDevice] getDPI

-----------------------
return nil
