-- @module CCImage

-----------------------
-- @function [parent=#CCImage] CCImage
-- @param  self

-----------------------
-- @function [parent=#CCImage] CCImage
-- @param  self

-----------------------
-- @function [parent=#CCImage] initWithImageFile
-- @param  self
-- @param  strPath
-- @param  kFmtPng

-----------------------
-- @function [parent=#CCImage] initWithImageFileThreadSafe
-- @param  self
-- @param  fullpath
-- @param  kFmtPng

-----------------------
-- @function [parent=#CCImage] hasAlpha
-- @param  self

-----------------------
-- @function [parent=#CCImage] isPremultipliedAlpha
-- @param  self

-----------------------
-- @function [parent=#CCImage] saveToFile
-- @param  self
-- @param  pszFilePath
-- @param  true

-----------------------
-- @function [parent=#CCImage] getWidth
-- @param  self

-----------------------
-- @function [parent=#CCImage] getHeight
-- @param  self

-----------------------
-- @function [parent=#CCImage] getBitsPerComponent
-- @param  self

-----------------------
return nil
