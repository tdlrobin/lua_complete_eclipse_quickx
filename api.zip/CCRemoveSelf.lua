-- @module CCRemoveSelf

-----------------------
-- @function [parent=#CCRemoveSelf] create
-- @param  true

-----------------------
return nil
