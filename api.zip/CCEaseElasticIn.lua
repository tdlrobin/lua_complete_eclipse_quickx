-- @module CCEaseElasticIn

-----------------------
-- @function [parent=#CCEaseElasticIn] create
-- @param  pAction
-- @param  fPeriod

-----------------------
-- @function [parent=#CCEaseElasticIn] create
-- @param  pAction

-----------------------
return nil
