-- @module CCShaderDisplayData

-----------------------
-- @function [parent=#CCShaderDisplayData] create

-----------------------
-- @function [parent=#CCShaderDisplayData] setParam
-- @param  self
-- @param  vert
-- @param  frag

-----------------------
-- @function [parent=#CCShaderDisplayData] copy
-- @param  self
-- @param  displayData

-----------------------
return nil
