-- @module CCLayerRGBA

-----------------------
-- @function [parent=#CCLayerRGBA] create

-----------------------
-- @function [parent=#CCLayerRGBA] getOpacity
-- @param  self

-----------------------
-- @function [parent=#CCLayerRGBA] getDisplayedOpacity
-- @param  self

-----------------------
-- @function [parent=#CCLayerRGBA] setOpacity
-- @param  self
-- @param  opacity

-----------------------
-- @function [parent=#CCLayerRGBA] updateDisplayedOpacity
-- @param  self
-- @param  parentOpacity

-----------------------
-- @function [parent=#CCLayerRGBA] isCascadeOpacityEnabled
-- @param  self

-----------------------
-- @function [parent=#CCLayerRGBA] setCascadeOpacityEnabled
-- @param  self
-- @param  cascadeOpacityEnabled

-----------------------
-- @function [parent=#CCLayerRGBA] getColor
-- @param  self

-----------------------
-- @function [parent=#CCLayerRGBA] getDisplayedColor
-- @param  self

-----------------------
-- @function [parent=#CCLayerRGBA] setColor
-- @param  self
-- @param  color

-----------------------
-- @function [parent=#CCLayerRGBA] updateDisplayedColor
-- @param  self
-- @param  parentColor

-----------------------
-- @function [parent=#CCLayerRGBA] isCascadeColorEnabled
-- @param  self

-----------------------
-- @function [parent=#CCLayerRGBA] setCascadeColorEnabled
-- @param  self
-- @param  cascadeColorEnabled

-----------------------
-- @function [parent=#CCLayerRGBA] setOpacityModifyRGB
-- @param  self
-- @param  bValue

-----------------------
-- @function [parent=#CCLayerRGBA] isOpacityModifyRGB
-- @param  self

-----------------------
return nil
