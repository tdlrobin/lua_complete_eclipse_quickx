-- @module CCBaseData

-----------------------
-- @function [parent=#CCBaseData] subtract
-- @param  self
-- @param  _from
-- @param  _to

-----------------------
return nil
