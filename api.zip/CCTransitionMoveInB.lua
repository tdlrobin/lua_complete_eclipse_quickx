-- @module CCTransitionMoveInB

-----------------------
-- @function [parent=#CCTransitionMoveInB] create
-- @param  t
-- @param  scene

-----------------------
return nil
