-- @module CCTMXObjectGroup

-----------------------
-- @function [parent=#CCTMXObjectGroup] getGroupName
-- @param  self

-----------------------
-- @function [parent=#CCTMXObjectGroup] propertyNamed
-- @param  self
-- @param  propertyName

-----------------------
-- @function [parent=#CCTMXObjectGroup] objectNamed
-- @param  self
-- @param  objectName

-----------------------
-- @function [parent=#CCTMXObjectGroup] getPositionOffset
-- @param  self

-----------------------
-- @function [parent=#CCTMXObjectGroup] setPositionOffset
-- @param  self
-- @param  p

-----------------------
-- @function [parent=#CCTMXObjectGroup] getProperties
-- @param  self

-----------------------
-- @function [parent=#CCTMXObjectGroup] getObjects
-- @param  self

-----------------------
return nil
