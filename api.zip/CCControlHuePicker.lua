-- @module CCControlHuePicker

-----------------------
-- @function [parent=#CCControlHuePicker] getHue
-- @param  self

-----------------------
-- @function [parent=#CCControlHuePicker] setHue
-- @param  self
-- @param  val

-----------------------
-- @function [parent=#CCControlHuePicker] getHuePercentage
-- @param  self

-----------------------
-- @function [parent=#CCControlHuePicker] setHuePercentage
-- @param  self
-- @param  val

-----------------------
-- @function [parent=#CCControlHuePicker] create
-- @param  target
-- @param  pos

-----------------------
return nil
