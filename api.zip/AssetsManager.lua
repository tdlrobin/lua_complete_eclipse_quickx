-- @module AssetsManager

-----------------------
-- @function [parent=#AssetsManager] AssetsManager
-- @param  self
-- @param  NULL
-- @param  NULL
-- @param  NULL

-----------------------
-- @function [parent=#AssetsManager] AssetsManager
-- @param  self

-----------------------
-- @function [parent=#AssetsManager] checkUpdate
-- @param  self

-----------------------
-- @function [parent=#AssetsManager] update
-- @param  self

-----------------------
-- @function [parent=#AssetsManager] getPackageUrl
-- @param  self

-----------------------
-- @function [parent=#AssetsManager] setPackageUrl
-- @param  self
-- @param  packageUrl

-----------------------
-- @function [parent=#AssetsManager] getVersionFileUrl
-- @param  self

-----------------------
-- @function [parent=#AssetsManager] setVersionFileUrl
-- @param  self
-- @param  versionFileUrl

-----------------------
-- @function [parent=#AssetsManager] getVersion
-- @param  self

-----------------------
-- @function [parent=#AssetsManager] deleteVersion
-- @param  self

-----------------------
-- @function [parent=#AssetsManager] getStoragePath
-- @param  self

-----------------------
-- @function [parent=#AssetsManager] setStoragePath
-- @param  self
-- @param  storagePath

-----------------------
-- @function [parent=#AssetsManager] setConnectionTimeout
-- @param  self
-- @param  timeout

-----------------------
-- @function [parent=#AssetsManager] getConnectionTimeout
-- @param  self

-----------------------
-- @function [parent=#AssetsManager] registerScriptHandler
-- @param  self
-- @param  handler

-----------------------
-- @function [parent=#AssetsManager] unregisterScriptHandler
-- @param  self
-- @param  void

-----------------------
return nil
