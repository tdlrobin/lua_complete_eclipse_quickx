-- @module CCTileMapAtlas

-----------------------
-- @function [parent=#CCTileMapAtlas] CCTileMapAtlas
-- @param  self

-----------------------
-- @function [parent=#CCTileMapAtlas] CCTileMapAtlas
-- @param  self

-----------------------
-- @function [parent=#CCTileMapAtlas] create
-- @param  tile
-- @param  mapFile
-- @param  tileWidth
-- @param  tileHeight

-----------------------
-- @function [parent=#CCTileMapAtlas] initWithTileFile
-- @param  self
-- @param  tile
-- @param  mapFile
-- @param  tileWidth
-- @param  tileHeight

-----------------------
-- @function [parent=#CCTileMapAtlas] tileAt
-- @param  self
-- @param  position

-----------------------
-- @function [parent=#CCTileMapAtlas] setTile
-- @param  self
-- @param  tile
-- @param  position

-----------------------
-- @function [parent=#CCTileMapAtlas] releaseMap
-- @param  self

-----------------------
return nil
