-- @module CCMenuItemLabel

-----------------------
-- @function [parent=#CCMenuItemLabel] create
-- @param  label
-- @param  target
-- @param  selector

-----------------------
-- @function [parent=#CCMenuItemLabel] create
-- @param  label

-----------------------
-- @function [parent=#CCMenuItemLabel] getDisabledColor
-- @param  self

-----------------------
-- @function [parent=#CCMenuItemLabel] setDisabledColor
-- @param  self
-- @param  color

-----------------------
-- @function [parent=#CCMenuItemLabel] getLabel
-- @param  self

-----------------------
-- @function [parent=#CCMenuItemLabel] setLabel
-- @param  self
-- @param  label

-----------------------
-- @function [parent=#CCMenuItemLabel] setString
-- @param  self
-- @param  label

-----------------------
return nil
