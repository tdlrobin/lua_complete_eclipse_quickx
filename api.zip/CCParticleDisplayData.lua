-- @module CCParticleDisplayData

-----------------------
-- @function [parent=#CCParticleDisplayData] create

-----------------------
-- @function [parent=#CCParticleDisplayData] setParam
-- @param  self
-- @param  plist

-----------------------
-- @function [parent=#CCParticleDisplayData] copy
-- @param  self
-- @param  displayData

-----------------------
return nil
