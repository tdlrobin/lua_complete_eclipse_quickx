-- @module CCRipple3D

-----------------------
-- @function [parent=#CCRipple3D] create
-- @param  duration
-- @param  gridSize
-- @param  position
-- @param  radius
-- @param  waves
-- @param  amplitude

-----------------------
return nil
