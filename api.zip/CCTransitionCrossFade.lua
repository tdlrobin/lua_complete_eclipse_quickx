-- @module CCTransitionCrossFade

-----------------------
-- @function [parent=#CCTransitionCrossFade] create
-- @param  t
-- @param  scene

-----------------------
return nil
