-- @module CCTransitionFade

-----------------------
-- @function [parent=#CCTransitionFade] create
-- @param  self
-- @param  2
-- @param  scene
-- @param  255
-- @param  0
-- @param  0

-----------------------
-- @function [parent=#CCTransitionFade] create
-- @param  duration
-- @param  scene
-- @param  color

-----------------------
-- @function [parent=#CCTransitionFade] create
-- @param  duration
-- @param  scene

-----------------------
return nil
