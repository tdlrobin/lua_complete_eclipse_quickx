-- @module EventProtocol

-----------------------
-- @function [parent=#EventProtocol] extend
-- @param  object

-----------------------
return nil
