-- @module CCMovementData

-----------------------
-- @function [parent=#CCMovementData] create

-----------------------
-- @function [parent=#CCMovementData] addMovementBoneData
-- @param  self
-- @param  movBoneData

-----------------------
-- @function [parent=#CCMovementData] getMovementBoneData
-- @param  self
-- @param  boneName

-----------------------
return nil
