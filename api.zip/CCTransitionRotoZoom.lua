-- @module CCTransitionRotoZoom

-----------------------
-- @function [parent=#CCTransitionRotoZoom] create
-- @param  t
-- @param  scene

-----------------------
return nil
