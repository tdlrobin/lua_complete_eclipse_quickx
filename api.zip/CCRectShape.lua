-- @module CCRectShape

-----------------------
-- @function [parent=#CCRectShape] create
-- @param  size

-----------------------
-- @function [parent=#CCRectShape] getSize
-- @param  self
-- @param  void

-----------------------
-- @function [parent=#CCRectShape] setSize
-- @param  self
-- @param  size

-----------------------
-- @function [parent=#CCRectShape] isFill
-- @param  self
-- @param  void

-----------------------
-- @function [parent=#CCRectShape] setFill
-- @param  self
-- @param  fill

-----------------------
return nil
