-- @module scheduler

-----------------------
-- @function [parent=#scheduler] scheduleUpdateGlobal
-- @param  listener

-----------------------
-- @function [parent=#scheduler] scheduleGlobal
-- @param  listener
-- @param  interval

-----------------------
-- @function [parent=#scheduler] unscheduleGlobal
-- @param  handle

-----------------------
-- @function [parent=#scheduler] performWithDelayGlobal
-- @param  listener
-- @param  time

-----------------------
return nil
