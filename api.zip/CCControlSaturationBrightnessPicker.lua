-- @module CCControlSaturationBrightnessPicker

-----------------------
-- @function [parent=#CCControlSaturationBrightnessPicker] getSaturation
-- @param  self

-----------------------
-- @function [parent=#CCControlSaturationBrightnessPicker] getBrightness
-- @param  self

-----------------------
-- @function [parent=#CCControlSaturationBrightnessPicker] create
-- @param  target
-- @param  pos

-----------------------
return nil
