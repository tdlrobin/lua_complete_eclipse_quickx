-- @module CCTransitionProgressInOut

-----------------------
-- @function [parent=#CCTransitionProgressInOut] create
-- @param  t
-- @param  scene

-----------------------
return nil
