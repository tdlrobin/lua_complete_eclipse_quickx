-- @module ui

-----------------------
-- @field [parent=#ui] DEFAULT_TTF_FONT

-----------------------
-- @field [parent=#ui] DEFAULT_TTF_FONT_SIZE

-----------------------
-- @field [parent=#ui] TEXT_ALIGN_LEFT

-----------------------
-- @field [parent=#ui] TEXT_ALIGN_CENTER

-----------------------
-- @field [parent=#ui] TEXT_ALIGN_RIGHT

-----------------------
-- @field [parent=#ui] TEXT_VALIGN_TOP

-----------------------
-- @field [parent=#ui] TEXT_VALIGN_CENTER

-----------------------
-- @field [parent=#ui] TEXT_VALIGN_BOTTOM

-----------------------
-- @function [parent=#ui] newEditBox
-- @param  params

-----------------------
-- @function [parent=#ui] newMenu
-- @param  items

-----------------------
-- @function [parent=#ui] newImageMenuItem
-- @param  params

-----------------------
-- @function [parent=#ui] newTTFLabelMenuItem
-- @param  params

-----------------------
-- @function [parent=#ui] newBMFontLabel
-- @param  params

-----------------------
-- @function [parent=#ui] newTTFLabel
-- @param  params

-----------------------
-- @function [parent=#ui] newTTFLabelWithShadow
-- @param  params

-----------------------
-- @function [parent=#ui] newTTFLabelWithOutline
-- @param  params

-----------------------
return nil
