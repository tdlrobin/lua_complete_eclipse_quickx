-- @module CCTransitionSlideInR

-----------------------
-- @function [parent=#CCTransitionSlideInR] create
-- @param  t
-- @param  scene

-----------------------
return nil
