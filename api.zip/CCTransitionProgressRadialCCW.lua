-- @module CCTransitionProgressRadialCCW

-----------------------
-- @function [parent=#CCTransitionProgressRadialCCW] create
-- @param  t
-- @param  scene

-----------------------
return nil
