-- @module CCOrbitCamera

-----------------------
-- @function [parent=#CCOrbitCamera] create
-- @param  t
-- @param  radius
-- @param  deltaRadius
-- @param  angleZ
-- @param  deltaAngleZ
-- @param  angleX
-- @param  deltaAngleX

-----------------------
-- @function [parent=#CCOrbitCamera] sphericalRadius
-- @param  self
-- @param  r
-- @param  zenith
-- @param  azimuth

-----------------------
return nil
