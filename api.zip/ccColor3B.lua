-- @module ccColor3B

-----------------------
-- @function [parent=#ccColor3B] ccColor3B
-- @param  self

-----------------------
-- @function [parent=#ccColor3B] ccColor3B
-- @param  self

-----------------------
return nil
