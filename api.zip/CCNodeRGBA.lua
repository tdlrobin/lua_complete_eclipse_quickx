-- @module CCNodeRGBA

-----------------------
-- @function [parent=#CCNodeRGBA] create
-- @param  void

-----------------------
-- @function [parent=#CCNodeRGBA] getOpacity
-- @param  self

-----------------------
-- @function [parent=#CCNodeRGBA] getDisplayedOpacity
-- @param  self

-----------------------
-- @function [parent=#CCNodeRGBA] setOpacity
-- @param  self
-- @param  opacity

-----------------------
-- @function [parent=#CCNodeRGBA] updateDisplayedOpacity
-- @param  self
-- @param  parentOpacity

-----------------------
-- @function [parent=#CCNodeRGBA] isCascadeOpacityEnabled
-- @param  self

-----------------------
-- @function [parent=#CCNodeRGBA] setCascadeOpacityEnabled
-- @param  self
-- @param  cascadeOpacityEnabled

-----------------------
-- @function [parent=#CCNodeRGBA] getColor
-- @param  self
-- @param  void

-----------------------
-- @function [parent=#CCNodeRGBA] getDisplayedColor
-- @param  self

-----------------------
-- @function [parent=#CCNodeRGBA] setColor
-- @param  self
-- @param  color

-----------------------
-- @function [parent=#CCNodeRGBA] updateDisplayedColor
-- @param  self
-- @param  parentColor

-----------------------
-- @function [parent=#CCNodeRGBA] isCascadeColorEnabled
-- @param  self

-----------------------
-- @function [parent=#CCNodeRGBA] setCascadeColorEnabled
-- @param  self
-- @param  cascadeColorEnabled

-----------------------
-- @function [parent=#CCNodeRGBA] setOpacityModifyRGB
-- @param  self
-- @param  bValue

-----------------------
-- @function [parent=#CCNodeRGBA] isOpacityModifyRGB
-- @param  self

-----------------------
return nil
