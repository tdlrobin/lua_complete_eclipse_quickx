-- @module network

-----------------------
-- @function [parent=#network] isLocalWiFiAvailable

-----------------------
-- @function [parent=#network] isInternetConnectionAvailable

-----------------------
-- @function [parent=#network] isHostNameReachable
-- @param  hostname

-----------------------
-- @function [parent=#network] getInternetConnectionStatus

-----------------------
-- @function [parent=#network] createHTTPRequest
-- @param  callback
-- @param  url
-- @param  method

-----------------------
return nil
