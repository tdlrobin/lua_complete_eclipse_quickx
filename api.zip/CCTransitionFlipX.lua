-- @module CCTransitionFlipX

-----------------------
-- @function [parent=#CCTransitionFlipX] create
-- @param  t
-- @param  s
-- @param  o

-----------------------
-- @function [parent=#CCTransitionFlipX] create
-- @param  t
-- @param  s

-----------------------
return nil
