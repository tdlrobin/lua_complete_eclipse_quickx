-- @module CCCallFuncN

-----------------------
-- @function [parent=#CCCallFuncN] create
-- @param  nHandler

-----------------------
return nil
