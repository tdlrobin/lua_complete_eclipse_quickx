-- @module CCProgressTimer

-----------------------
-- @function [parent=#CCProgressTimer] getType
-- @param  self
-- @param  void

-----------------------
-- @function [parent=#CCProgressTimer] setType
-- @param  self
-- @param  type

-----------------------
-- @function [parent=#CCProgressTimer] getPercentage
-- @param  self
-- @param  void

-----------------------
-- @function [parent=#CCProgressTimer] setPercentage
-- @param  self
-- @param  fPercentage

-----------------------
-- @function [parent=#CCProgressTimer] setReverseProgress
-- @param  self
-- @param  reverse

-----------------------
-- @function [parent=#CCProgressTimer] getSprite
-- @param  self
-- @param  void

-----------------------
-- @function [parent=#CCProgressTimer] setSprite
-- @param  self
-- @param  pSprite

-----------------------
-- @function [parent=#CCProgressTimer] isReverseDirection
-- @param  self

-----------------------
-- @function [parent=#CCProgressTimer] setReverseDirection
-- @param  self
-- @param  value

-----------------------
-- @function [parent=#CCProgressTimer] getMidpoint
-- @param  self

-----------------------
-- @function [parent=#CCProgressTimer] setMidpoint
-- @param  self
-- @param  p

-----------------------
-- @function [parent=#CCProgressTimer] getBarChangeRate
-- @param  self

-----------------------
-- @function [parent=#CCProgressTimer] setBarChangeRate
-- @param  self
-- @param  p

-----------------------
-- @function [parent=#CCProgressTimer] create
-- @param  sp

-----------------------
return nil
