-- @module CCSpriteDisplayData

-----------------------
-- @function [parent=#CCSpriteDisplayData] create

-----------------------
-- @function [parent=#CCSpriteDisplayData] setParam
-- @param  self
-- @param  displayName

-----------------------
-- @function [parent=#CCSpriteDisplayData] copy
-- @param  self
-- @param  displayData

-----------------------
return nil
