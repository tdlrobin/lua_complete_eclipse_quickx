-- @module CCTMXTiledMap

-----------------------
-- @function [parent=#CCTMXTiledMap] create
-- @param  tmxFile

-----------------------
-- @function [parent=#CCTMXTiledMap] createWithXML
-- @param  tmxString
-- @param  resourcePath

-----------------------
-- @function [parent=#CCTMXTiledMap] layerNamed
-- @param  self
-- @param  layerName

-----------------------
-- @function [parent=#CCTMXTiledMap] objectGroupNamed
-- @param  self
-- @param  groupName

-----------------------
-- @function [parent=#CCTMXTiledMap] propertyNamed
-- @param  self
-- @param  propertyName

-----------------------
-- @function [parent=#CCTMXTiledMap] propertiesForGID
-- @param  self
-- @param  GID

-----------------------
-- @function [parent=#CCTMXTiledMap] getMapSize
-- @param  self

-----------------------
-- @function [parent=#CCTMXTiledMap] getTileSize
-- @param  self

-----------------------
-- @function [parent=#CCTMXTiledMap] getMapOrientation
-- @param  self

-----------------------
-- @function [parent=#CCTMXTiledMap] getObjectGroups
-- @param  self

-----------------------
-- @function [parent=#CCTMXTiledMap] getProperties
-- @param  self

-----------------------
return nil
