-- @module CCFlipX

-----------------------
-- @function [parent=#CCFlipX] create
-- @param  x

-----------------------
return nil
