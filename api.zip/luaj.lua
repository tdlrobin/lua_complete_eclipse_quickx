-- @module luaj

-----------------------
-- @function [parent=#luaj] callStaticMethod
-- @param  className
-- @param  methodName
-- @param  args
-- @param  sig

-----------------------
return nil
