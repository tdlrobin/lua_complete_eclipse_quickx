-- @module CCAnimationData

-----------------------
-- @function [parent=#CCAnimationData] create

-----------------------
-- @function [parent=#CCAnimationData] addMovement
-- @param  self
-- @param  movData

-----------------------
-- @function [parent=#CCAnimationData] getMovement
-- @param  self
-- @param  movementName

-----------------------
-- @function [parent=#CCAnimationData] getMovementCount
-- @param  self

-----------------------
return nil
