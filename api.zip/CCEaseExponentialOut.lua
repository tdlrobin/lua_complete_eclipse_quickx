-- @module CCEaseExponentialOut

-----------------------
-- @function [parent=#CCEaseExponentialOut] create
-- @param  pAction

-----------------------
return nil
