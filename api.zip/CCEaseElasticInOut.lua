-- @module CCEaseElasticInOut

-----------------------
-- @function [parent=#CCEaseElasticInOut] create
-- @param  pAction
-- @param  fPeriod

-----------------------
-- @function [parent=#CCEaseElasticInOut] create
-- @param  pAction

-----------------------
return nil
