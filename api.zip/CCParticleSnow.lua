-- @module CCParticleSnow

-----------------------
-- @function [parent=#CCParticleSnow] createWithTotalParticles
-- @param  numberOfParticles

-----------------------
-- @function [parent=#CCParticleSnow] create

-----------------------
return nil
