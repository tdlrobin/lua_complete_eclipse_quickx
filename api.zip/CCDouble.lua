-- @module CCDouble

-----------------------
-- @function [parent=#CCDouble] CCDouble
-- @param  self
-- @param  v

-----------------------
-- @function [parent=#CCDouble] getValue
-- @param  self

-----------------------
-- @function [parent=#CCDouble] create
-- @param  v

-----------------------
return nil
