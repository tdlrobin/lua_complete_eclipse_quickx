-- @module CCCircleShape

-----------------------
-- @function [parent=#CCCircleShape] create
-- @param  radius

-----------------------
-- @function [parent=#CCCircleShape] getRadius
-- @param  self
-- @param  void

-----------------------
-- @function [parent=#CCCircleShape] setRadius
-- @param  self
-- @param  radius

-----------------------
-- @function [parent=#CCCircleShape] getAngle
-- @param  self
-- @param  void

-----------------------
-- @function [parent=#CCCircleShape] setAngle
-- @param  self
-- @param  angle

-----------------------
-- @function [parent=#CCCircleShape] getSegments
-- @param  self
-- @param  void

-----------------------
-- @function [parent=#CCCircleShape] setSegments
-- @param  self
-- @param  segments

-----------------------
-- @function [parent=#CCCircleShape] isDrawLineToCenter
-- @param  self
-- @param  void

-----------------------
-- @function [parent=#CCCircleShape] setDrawLineToCenter
-- @param  self
-- @param  drawLineToCenter

-----------------------
return nil
