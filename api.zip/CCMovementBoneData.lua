-- @module CCMovementBoneData

-----------------------
-- @function [parent=#CCMovementBoneData] create

-----------------------
-- @function [parent=#CCMovementBoneData] addFrameData
-- @param  self
-- @param  frameData

-----------------------
-- @function [parent=#CCMovementBoneData] getFrameData
-- @param  self
-- @param  index

-----------------------
return nil
