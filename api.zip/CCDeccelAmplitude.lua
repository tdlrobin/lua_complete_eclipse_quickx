-- @module CCDeccelAmplitude

-----------------------
-- @function [parent=#CCDeccelAmplitude] create
-- @param  pAction
-- @param  duration

-----------------------
return nil
