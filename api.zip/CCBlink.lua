-- @module CCBlink

-----------------------
-- @function [parent=#CCBlink] create
-- @param  duration
-- @param  uBlinks

-----------------------
return nil
