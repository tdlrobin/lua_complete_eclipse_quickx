-- @module CCLabelAtlas

-----------------------
-- @function [parent=#CCLabelAtlas] create
-- @param  text
-- @param  charMapFile
-- @param  itemWidth
-- @param  itemHeight
-- @param  startCharMap

-----------------------
-- @function [parent=#CCLabelAtlas] create
-- @param  text
-- @param  fntFile

-----------------------
-- @function [parent=#CCLabelAtlas] setString
-- @param  self
-- @param  label

-----------------------
-- @function [parent=#CCLabelAtlas] getString
-- @param  self
-- @param  void

-----------------------
return nil
