-- @module CCArmature

-----------------------
-- @function [parent=#CCArmature] create
-- @param  name
-- @param  parentBone

-----------------------
-- @function [parent=#CCArmature] create
-- @param  name

-----------------------
-- @function [parent=#CCArmature] create

-----------------------
-- @function [parent=#CCArmature] addBone
-- @param  self
-- @param  bone
-- @param  parentName

-----------------------
-- @function [parent=#CCArmature] changeBoneParent
-- @param  self
-- @param  bone
-- @param  parentName

-----------------------
-- @function [parent=#CCArmature] removeBone
-- @param  self
-- @param  bone
-- @param  true

-----------------------
-- @function [parent=#CCArmature] getBoneDic
-- @param  self

-----------------------
-- @function [parent=#CCArmature] boundingBox
-- @param  self

-----------------------
-- @function [parent=#CCArmature] getBoneAtPoint
-- @param  self
-- @param  x
-- @param  y

-----------------------
-- @function [parent=#CCArmature] getAnimation
-- @param  self

-----------------------
-- @function [parent=#CCArmature] getBatchNode
-- @param  self

-----------------------
-- @function [parent=#CCArmature] getName
-- @param  self

-----------------------
-- @function [parent=#CCArmature] getTextureAtlas
-- @param  self

-----------------------
-- @function [parent=#CCArmature] getParentBone
-- @param  self

-----------------------
return nil
