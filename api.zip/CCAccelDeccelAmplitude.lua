-- @module CCAccelDeccelAmplitude

-----------------------
-- @function [parent=#CCAccelDeccelAmplitude] create
-- @param  pAction
-- @param  duration

-----------------------
return nil
