-- @module CCDisplayData

-----------------------
-- @function [parent=#CCDisplayData] create

-----------------------
-- @function [parent=#CCDisplayData] changeDisplayToTexture
-- @param  static const char

-----------------------
return nil
