-- @module CCBatchNode

-----------------------
-- @function [parent=#CCBatchNode] create

-----------------------
return nil
