-- @module CCPolygonShape

-----------------------
-- @function [parent=#CCPolygonShape] create
-- @param  vertices

-----------------------
-- @function [parent=#CCPolygonShape] isFill
-- @param  self
-- @param  void

-----------------------
-- @function [parent=#CCPolygonShape] setFill
-- @param  self
-- @param  fill

-----------------------
-- @function [parent=#CCPolygonShape] isClose
-- @param  self
-- @param  void

-----------------------
-- @function [parent=#CCPolygonShape] setClose
-- @param  self
-- @param  close

-----------------------
return nil
