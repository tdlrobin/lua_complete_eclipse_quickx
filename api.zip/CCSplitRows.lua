-- @module CCSplitRows

-----------------------
-- @function [parent=#CCSplitRows] create
-- @param  duration
-- @param  nRows

-----------------------
return nil
