-- @module CCArmatureAnimation

-----------------------
-- @function [parent=#CCArmatureAnimation] create
-- @param  armature

-----------------------
-- @function [parent=#CCArmatureAnimation] setAnimationScale
-- @param  self
-- @param  animationScale

-----------------------
-- @function [parent=#CCArmatureAnimation] play
-- @param  self
-- @param  animationName
-- @param  1
-- @param  1
-- @param  1
-- @param  TWEEN_EASING_MAX

-----------------------
-- @function [parent=#CCArmatureAnimation] playByIndex
-- @param  self
-- @param  animationIndex
-- @param  1
-- @param  1
-- @param  1
-- @param  TWEEN_EASING_MAX

-----------------------
-- @function [parent=#CCArmatureAnimation] pause
-- @param  self

-----------------------
-- @function [parent=#CCArmatureAnimation] resume
-- @param  self

-----------------------
-- @function [parent=#CCArmatureAnimation] stop
-- @param  self

-----------------------
-- @function [parent=#CCArmatureAnimation] getMovementCount
-- @param  self

-----------------------
-- @function [parent=#CCArmatureAnimation] getAnimationData
-- @param  self

-----------------------
-- @function [parent=#CCArmatureAnimation] setAnimationData
-- @param  self
-- @param  void

-----------------------
return nil
