-- @module CCTransitionProgressRadialCW

-----------------------
-- @function [parent=#CCTransitionProgressRadialCW] create
-- @param  t
-- @param  scene

-----------------------
return nil
