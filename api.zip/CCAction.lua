-- @module CCAction

-----------------------
-- @function [parent=#CCAction] isDone
-- @param  self
-- @param  void

-----------------------
-- @function [parent=#CCAction] step
-- @param  self
-- @param  dt

-----------------------
-- @function [parent=#CCAction] update
-- @param  self
-- @param  time

-----------------------
-- @function [parent=#CCAction] getTag
-- @param  self
-- @param  void

-----------------------
-- @function [parent=#CCAction] setTag
-- @param  self
-- @param  nTag

-----------------------
return nil
