-- @module crypto

-----------------------
-- @function [parent=#crypto] encryptAES256
-- @param  plaintext
-- @param  key

-----------------------
-- @function [parent=#crypto] decryptAES256
-- @param  ciphertext
-- @param  key

-----------------------
-- @function [parent=#crypto] encryptXXTEA
-- @param  plaintext
-- @param  key

-----------------------
-- @function [parent=#crypto] decryptXXTEA
-- @param  ciphertext
-- @param  key

-----------------------
-- @function [parent=#crypto] encodeBase64
-- @param  plaintext

-----------------------
-- @function [parent=#crypto] decodeBase64
-- @param  ciphertext

-----------------------
-- @function [parent=#crypto] md5
-- @param  input
-- @param  isRawOutput

-----------------------
return nil
