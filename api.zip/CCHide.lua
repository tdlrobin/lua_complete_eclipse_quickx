-- @module CCHide

-----------------------
-- @function [parent=#CCHide] create

-----------------------
return nil
