-- @module CCActionCamera

-----------------------
return nil
