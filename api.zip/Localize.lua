-- @module Localize

-----------------------
-- @field [parent=#Localize] strings

-----------------------
-- @field [parent=#Localize] strings

-----------------------
-- @function [parent=#Localize] loadStrings
-- @param  strings

-----------------------
-- @function [parent=#Localize] query
-- @param  key
-- @param  default

-----------------------
-- @function [parent=#Localize] filename
-- @param  filenameOrigin

-----------------------
return nil
