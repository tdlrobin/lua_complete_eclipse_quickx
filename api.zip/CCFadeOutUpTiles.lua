-- @module CCFadeOutUpTiles

-----------------------
-- @function [parent=#CCFadeOutUpTiles] create
-- @param  duration
-- @param  gridSize

-----------------------
return nil
