-- @module CCLabelTTF

-----------------------
-- @function [parent=#CCLabelTTF] CCLabelTTF
-- @param  self

-----------------------
-- @function [parent=#CCLabelTTF] CCLabelTTF
-- @param  self

-----------------------
-- @function [parent=#CCLabelTTF] create
-- @param  text
-- @param  fontName
-- @param  fontSize

-----------------------
-- @function [parent=#CCLabelTTF] create

-----------------------
-- @function [parent=#CCLabelTTF] initWithString
-- @param  self
-- @param  text
-- @param  fontName
-- @param  fontSize

-----------------------
-- @function [parent=#CCLabelTTF] initWithStringAndTextDefinition
-- @param  self
-- @param  text
-- @param  textDefinition

-----------------------
-- @function [parent=#CCLabelTTF] init
-- @param  self

-----------------------
-- @function [parent=#CCLabelTTF] setTextDefinition
-- @param  self
-- @param  theDefinition

-----------------------
-- @function [parent=#CCLabelTTF] getTextDefinition
-- @param  self

-----------------------
-- @function [parent=#CCLabelTTF] enableShadow
-- @param  self
-- @param  shadowOffset
-- @param  shadowOpacity
-- @param  shadowBlur
-- @param  true

-----------------------
-- @function [parent=#CCLabelTTF] disableShadow
-- @param  self
-- @param  true

-----------------------
-- @function [parent=#CCLabelTTF] enableStroke
-- @param  self
-- @param  strokeColor
-- @param  strokeSize
-- @param  true

-----------------------
-- @function [parent=#CCLabelTTF] disableStroke
-- @param  self
-- @param  true

-----------------------
-- @function [parent=#CCLabelTTF] setFontFillColor
-- @param  self
-- @param  tintColor
-- @param  true

-----------------------
-- @function [parent=#CCLabelTTF] setString
-- @param  self
-- @param  label

-----------------------
-- @function [parent=#CCLabelTTF] getString
-- @param  self
-- @param  void

-----------------------
-- @function [parent=#CCLabelTTF] getHorizontalAlignment
-- @param  self

-----------------------
-- @function [parent=#CCLabelTTF] setHorizontalAlignment
-- @param  self
-- @param  alignment

-----------------------
-- @function [parent=#CCLabelTTF] getVerticalAlignment
-- @param  self

-----------------------
-- @function [parent=#CCLabelTTF] setVerticalAlignment
-- @param  self
-- @param  verticalAlignment

-----------------------
-- @function [parent=#CCLabelTTF] getDimensions
-- @param  self

-----------------------
-- @function [parent=#CCLabelTTF] setDimensions
-- @param  self
-- @param  dim

-----------------------
-- @function [parent=#CCLabelTTF] getFontSize
-- @param  self

-----------------------
-- @function [parent=#CCLabelTTF] setFontSize
-- @param  self
-- @param  fontSize

-----------------------
-- @function [parent=#CCLabelTTF] getFontName
-- @param  self

-----------------------
-- @function [parent=#CCLabelTTF] setFontName
-- @param  self
-- @param  fontName

-----------------------
return nil
