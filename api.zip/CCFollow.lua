-- @module CCFollow

-----------------------
-- @function [parent=#CCFollow] isBoundarySet
-- @param  self
-- @param  void

-----------------------
-- @function [parent=#CCFollow] setBoudarySet
-- @param  self
-- @param  bValue

-----------------------
-- @function [parent=#CCFollow] create
-- @param  pFollowedNode
-- @param  0
-- @param  0
-- @param  0
-- @param  static CCFollow

-----------------------
return nil
