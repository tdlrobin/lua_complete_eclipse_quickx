-- @module CCEaseBounceInOut

-----------------------
-- @function [parent=#CCEaseBounceInOut] create
-- @param  pAction

-----------------------
return nil
