-- @module CCTiledGrid3DAction

-----------------------
-- @function [parent=#CCTiledGrid3DAction] create
-- @param  duration
-- @param  gridSize

-----------------------
return nil
