-- @module CCSkewTo

-----------------------
-- @function [parent=#CCSkewTo] create
-- @param  t
-- @param  sx
-- @param  sy

-----------------------
return nil
