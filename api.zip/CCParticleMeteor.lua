-- @module CCParticleMeteor

-----------------------
-- @function [parent=#CCParticleMeteor] createWithTotalParticles
-- @param  numberOfParticles

-----------------------
-- @function [parent=#CCParticleMeteor] create

-----------------------
return nil
