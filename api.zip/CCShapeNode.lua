-- @module CCShapeNode

-----------------------
-- @function [parent=#CCShapeNode] getColor
-- @param  self
-- @param  void

-----------------------
-- @function [parent=#CCShapeNode] setColor
-- @param  self
-- @param  color

-----------------------
-- @function [parent=#CCShapeNode] getLineWidth
-- @param  self
-- @param  void

-----------------------
-- @function [parent=#CCShapeNode] setLineWidth
-- @param  self
-- @param  lineWidth

-----------------------
-- @function [parent=#CCShapeNode] getLineStipple
-- @param  self
-- @param  void

-----------------------
-- @function [parent=#CCShapeNode] setLineStipple
-- @param  self
-- @param  pattern

-----------------------
-- @function [parent=#CCShapeNode] isLineStippleEnabled
-- @param  self
-- @param  void

-----------------------
-- @function [parent=#CCShapeNode] setLineStippleEnabled
-- @param  self
-- @param  lineStippleEnabled

-----------------------
return nil
