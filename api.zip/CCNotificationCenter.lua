-- @module CCNotificationCenter

-----------------------
-- @function [parent=#CCNotificationCenter] sharedNotificationCenter
-- @param  void

-----------------------
-- @function [parent=#CCNotificationCenter] purgeNotificationCenter
-- @param  void

-----------------------
-- @function [parent=#CCNotificationCenter] removeObserver
-- @param  self
-- @param  target
-- @param  name

-----------------------
-- @function [parent=#CCNotificationCenter] removeAllObservers
-- @param  self
-- @param  target

-----------------------
-- @function [parent=#CCNotificationCenter] registerScriptObserver
-- @param  self
-- @param  target
-- @param  handler
-- @param  name

-----------------------
-- @function [parent=#CCNotificationCenter] unregisterScriptObserver
-- @param  self
-- @param  target
-- @param  name

-----------------------
-- @function [parent=#CCNotificationCenter] postNotification
-- @param  self
-- @param  name
-- @param  object

-----------------------
-- @function [parent=#CCNotificationCenter] postNotification
-- @param  self
-- @param  name

-----------------------
return nil
