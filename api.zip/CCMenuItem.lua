-- @module CCMenuItem

-----------------------
-- @function [parent=#CCMenuItem] create

-----------------------
-- @function [parent=#CCMenuItem] rect
-- @param  self

-----------------------
-- @function [parent=#CCMenuItem] activate
-- @param  self

-----------------------
-- @function [parent=#CCMenuItem] selected
-- @param  self

-----------------------
-- @function [parent=#CCMenuItem] unselected
-- @param  self

-----------------------
-- @function [parent=#CCMenuItem] registerScriptTapHandler
-- @param  self
-- @param  nHandler

-----------------------
-- @function [parent=#CCMenuItem] unregisterScriptTapHandler
-- @param  self
-- @param  void

-----------------------
-- @function [parent=#CCMenuItem] isEnabled
-- @param  self

-----------------------
-- @function [parent=#CCMenuItem] setEnabled
-- @param  self
-- @param  value

-----------------------
-- @function [parent=#CCMenuItem] isSelected
-- @param  self

-----------------------
return nil
