-- @module CCSequence

-----------------------
-- @function [parent=#CCSequence] create
-- @param  arrayOfActions

-----------------------
-- @function [parent=#CCSequence] createWithTwoActions
-- @param  pActionOne
-- @param  pActionTwo

-----------------------
return nil
