-- @module ccBlendFunc

-----------------------
-- @function [parent=#ccBlendFunc] ccBlendFunc
-- @param  self

-----------------------
-- @function [parent=#ccBlendFunc] ccBlendFunc
-- @param  self

-----------------------
return nil
