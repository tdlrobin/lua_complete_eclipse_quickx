-- @module CCJumpBy

-----------------------
-- @function [parent=#CCJumpBy] create
-- @param  duration
-- @param  position
-- @param  height
-- @param  jumps

-----------------------
return nil
