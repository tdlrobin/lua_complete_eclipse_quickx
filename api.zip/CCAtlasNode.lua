-- @module CCAtlasNode

-----------------------
-- @function [parent=#CCAtlasNode] getTextureAtlas
-- @param  self

-----------------------
-- @function [parent=#CCAtlasNode] getBlendFunc
-- @param  self

-----------------------
-- @function [parent=#CCAtlasNode] getQuadsToDraw
-- @param  self

-----------------------
-- @function [parent=#CCAtlasNode] CCAtlasNode
-- @param  self

-----------------------
-- @function [parent=#CCAtlasNode] CCAtlasNode
-- @param  self

-----------------------
-- @function [parent=#CCAtlasNode] initWithTileFile
-- @param  self
-- @param  tile
-- @param  tileWidth
-- @param  tileHeight
-- @param  itemsToRender

-----------------------
-- @function [parent=#CCAtlasNode] initWithTexture
-- @param  self
-- @param  texture
-- @param  tileWidth
-- @param  tileHeight
-- @param  itemsToRender

-----------------------
-- @function [parent=#CCAtlasNode] updateAtlasValues
-- @param  self

-----------------------
-- @function [parent=#CCAtlasNode] getTexture
-- @param  self
-- @param  void

-----------------------
-- @function [parent=#CCAtlasNode] setTexture
-- @param  self
-- @param  texture

-----------------------
-- @function [parent=#CCAtlasNode] isOpacityModifyRGB
-- @param  self

-----------------------
-- @function [parent=#CCAtlasNode] setOpacityModifyRGB
-- @param  self
-- @param  isOpacityModifyRGB

-----------------------
-- @function [parent=#CCAtlasNode] getColor
-- @param  self
-- @param  void

-----------------------
-- @function [parent=#CCAtlasNode] setColor
-- @param  self
-- @param  color

-----------------------
-- @function [parent=#CCAtlasNode] setOpacity
-- @param  self
-- @param  opacity

-----------------------
return nil
