-- @module CCTransitionFadeUp

-----------------------
-- @function [parent=#CCTransitionFadeUp] create
-- @param  t
-- @param  scene

-----------------------
return nil
