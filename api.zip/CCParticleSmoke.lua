-- @module CCParticleSmoke

-----------------------
-- @function [parent=#CCParticleSmoke] createWithTotalParticles
-- @param  numberOfParticles

-----------------------
-- @function [parent=#CCParticleSmoke] create

-----------------------
return nil
