-- @module CCParticleFireworks

-----------------------
-- @function [parent=#CCParticleFireworks] createWithTotalParticles
-- @param  numberOfParticles

-----------------------
-- @function [parent=#CCParticleFireworks] create

-----------------------
return nil
