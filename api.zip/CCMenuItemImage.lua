-- @module CCMenuItemImage

-----------------------
-- @function [parent=#CCMenuItemImage] create
-- @param  normalImage
-- @param  selectedImage
-- @param  disabledImage

-----------------------
-- @function [parent=#CCMenuItemImage] create
-- @param  normalImage
-- @param  selectedImage

-----------------------
-- @function [parent=#CCMenuItemImage] create

-----------------------
-- @function [parent=#CCMenuItemImage] setNormalSpriteFrame
-- @param  self
-- @param  frame

-----------------------
-- @function [parent=#CCMenuItemImage] setSelectedSpriteFrame
-- @param  self
-- @param  frame

-----------------------
-- @function [parent=#CCMenuItemImage] setDisabledSpriteFrame
-- @param  self
-- @param  frame

-----------------------
return nil
