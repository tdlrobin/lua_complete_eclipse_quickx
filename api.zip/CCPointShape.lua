-- @module CCPointShape

-----------------------
-- @function [parent=#CCPointShape] create
-- @param  void

-----------------------
return nil
