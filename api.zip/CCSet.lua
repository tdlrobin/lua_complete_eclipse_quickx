-- @module CCSet

-----------------------
-- @function [parent=#CCSet] create

-----------------------
-- @function [parent=#CCSet] copy
-- @param  self

-----------------------
-- @function [parent=#CCSet] mutableCopy
-- @param  self

-----------------------
-- @function [parent=#CCSet] count
-- @param  self

-----------------------
-- @function [parent=#CCSet] addObject
-- @param  self
-- @param  pObject

-----------------------
-- @function [parent=#CCSet] removeObject
-- @param  self
-- @param  pObject

-----------------------
-- @function [parent=#CCSet] removeAllObjects
-- @param  self

-----------------------
-- @function [parent=#CCSet] containsObject
-- @param  self
-- @param  pObject

-----------------------
-- @function [parent=#CCSet] anyObject
-- @param  self

-----------------------
return nil
