-- @module transition

-----------------------
-- @function [parent=#transition] create
-- @param  action
-- @param  args

-----------------------
-- @function [parent=#transition] execute
-- @param  target
-- @param  action
-- @param  args

-----------------------
-- @function [parent=#transition] rotateTo
-- @param  target
-- @param  args

-----------------------
-- @function [parent=#transition] moveTo
-- @param  target
-- @param  args

-----------------------
-- @function [parent=#transition] moveBy
-- @param  target
-- @param  args

-----------------------
-- @function [parent=#transition] fadeIn
-- @param  target
-- @param  args

-----------------------
-- @function [parent=#transition] fadeOut
-- @param  target
-- @param  args

-----------------------
-- @function [parent=#transition] fadeTo
-- @param  target
-- @param  args

-----------------------
-- @function [parent=#transition] scaleTo
-- @param  target
-- @param  args

-----------------------
-- @function [parent=#transition] sequence
-- @param  actions

-----------------------
-- @function [parent=#transition] playAnimationOnce
-- @param  target
-- @param  animation
-- @param  removeWhenFinished
-- @param  onComplete
-- @param  delay

-----------------------
-- @function [parent=#transition] playAnimationForever
-- @param  target
-- @param  animation
-- @param  delay

-----------------------
-- @function [parent=#transition] removeAction
-- @param  action

-----------------------
-- @function [parent=#transition] stopTarget
-- @param  target

-----------------------
-- @function [parent=#transition] pauseTarget
-- @param  target

-----------------------
-- @function [parent=#transition] resumeTarget
-- @param  target

-----------------------
return nil
