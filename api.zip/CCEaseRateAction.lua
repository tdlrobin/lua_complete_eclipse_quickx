-- @module CCEaseRateAction

-----------------------
-- @function [parent=#CCEaseRateAction] create
-- @param  pAction
-- @param  fRate

-----------------------
return nil
