-- @module CCTransitionFadeDown

-----------------------
-- @function [parent=#CCTransitionFadeDown] create
-- @param  t
-- @param  scene

-----------------------
return nil
