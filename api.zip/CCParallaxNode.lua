-- @module CCParallaxNode

-----------------------
-- @function [parent=#CCParallaxNode] create

-----------------------
-- @function [parent=#CCParallaxNode] addChild
-- @param  self
-- @param  child
-- @param  z
-- @param  parallaxRatio
-- @param  positionOffset

-----------------------
return nil
