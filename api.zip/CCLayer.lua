-- @module CCLayer

-----------------------
-- @function [parent=#CCLayer] create
-- @param  void

-----------------------
-- @function [parent=#CCLayer] registerScriptTouchHandler
-- @param  self
-- @param  nHandler
-- @param  false
-- @param  0
-- @param  false

-----------------------
-- @function [parent=#CCLayer] unregisterScriptTouchHandler
-- @param  self
-- @param  void

-----------------------
-- @function [parent=#CCLayer] setTouchEnabled
-- @param  self
-- @param  value

-----------------------
-- @function [parent=#CCLayer] isTouchEnabled
-- @param  self

-----------------------
-- @function [parent=#CCLayer] getTouchMode
-- @param  self

-----------------------
-- @function [parent=#CCLayer] setTouchMode
-- @param  self
-- @param  mode

-----------------------
-- @function [parent=#CCLayer] getTouchPriority
-- @param  self

-----------------------
-- @function [parent=#CCLayer] setTouchPriority
-- @param  self
-- @param  priority

-----------------------
-- @function [parent=#CCLayer] registerScriptKeypadHandler
-- @param  self
-- @param  nHandler

-----------------------
-- @function [parent=#CCLayer] unregisterScriptKeypadHandler
-- @param  self
-- @param  void

-----------------------
-- @function [parent=#CCLayer] setKeypadEnabled
-- @param  self
-- @param  value

-----------------------
-- @function [parent=#CCLayer] isKeypadEnabled
-- @param  self

-----------------------
-- @function [parent=#CCLayer] registerScriptAccelerateHandler
-- @param  self
-- @param  nHandler

-----------------------
-- @function [parent=#CCLayer] unregisterScriptAccelerateHandler
-- @param  self
-- @param  void

-----------------------
-- @function [parent=#CCLayer] setAccelerometerEnabled
-- @param  self
-- @param  value

-----------------------
-- @function [parent=#CCLayer] isAccelerometerEnabled
-- @param  self

-----------------------
-- @function [parent=#CCLayer] setAccelerometerInterval
-- @param  self
-- @param  interval

-----------------------
return nil
