-- @module CCShuffleTiles

-----------------------
-- @function [parent=#CCShuffleTiles] create
-- @param  duration
-- @param  gridSize
-- @param  seed

-----------------------
return nil
