-- @module CCParticleExplosion

-----------------------
-- @function [parent=#CCParticleExplosion] createWithTotalParticles
-- @param  numberOfParticles

-----------------------
-- @function [parent=#CCParticleExplosion] create

-----------------------
return nil
