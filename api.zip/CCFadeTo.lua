-- @module CCFadeTo

-----------------------
-- @function [parent=#CCFadeTo] create
-- @param  duration
-- @param  opacity

-----------------------
return nil
