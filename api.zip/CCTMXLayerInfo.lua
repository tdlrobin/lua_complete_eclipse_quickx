-- @module CCTMXLayerInfo

-----------------------
-- @function [parent=#CCTMXLayerInfo] getProperties
-- @param  self

-----------------------
-- @function [parent=#CCTMXLayerInfo] CCTMXLayerInfo
-- @param  self

-----------------------
-- @function [parent=#CCTMXLayerInfo] CCTMXLayerInfo
-- @param  self

-----------------------
return nil
