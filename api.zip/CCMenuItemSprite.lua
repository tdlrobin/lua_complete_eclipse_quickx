-- @module CCMenuItemSprite

-----------------------
-- @function [parent=#CCMenuItemSprite] getNormalImage
-- @param  self

-----------------------
-- @function [parent=#CCMenuItemSprite] setNormalImage
-- @param  self
-- @param  node

-----------------------
-- @function [parent=#CCMenuItemSprite] getSelectedImage
-- @param  self

-----------------------
-- @function [parent=#CCMenuItemSprite] setSelectedImage
-- @param  self
-- @param  node

-----------------------
-- @function [parent=#CCMenuItemSprite] getDisabledImage
-- @param  self

-----------------------
-- @function [parent=#CCMenuItemSprite] setDisabledImage
-- @param  self
-- @param  node

-----------------------
-- @function [parent=#CCMenuItemSprite] create
-- @param  normalSprite
-- @param  selectedSprite
-- @param  NULL

-----------------------
return nil
