-- @module CCTintBy

-----------------------
-- @function [parent=#CCTintBy] create
-- @param  duration
-- @param  deltaRed
-- @param  deltaGreen
-- @param  deltaBlue

-----------------------
return nil
